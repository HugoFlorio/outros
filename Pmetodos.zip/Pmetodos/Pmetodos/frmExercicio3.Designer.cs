﻿namespace Pmetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPalavra2 = new TextBox();
            txtPalavra1 = new TextBox();
            lblPalavra2 = new Label();
            lblPalavra1 = new Label();
            btnInverter = new Button();
            btnRemover = new Button();
            SuspendLayout();
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(254, 105);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(387, 31);
            txtPalavra2.TabIndex = 13;
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(254, 43);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(387, 31);
            txtPalavra1.TabIndex = 12;
            // 
            // lblPalavra2
            // 
            lblPalavra2.AutoSize = true;
            lblPalavra2.Location = new Point(159, 105);
            lblPalavra2.Name = "lblPalavra2";
            lblPalavra2.Size = new Size(82, 25);
            lblPalavra2.TabIndex = 10;
            lblPalavra2.Text = "Palavra 2";
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Location = new Point(159, 46);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(82, 25);
            lblPalavra1.TabIndex = 9;
            lblPalavra1.Text = "Palavra 1";
            // 
            // btnInverter
            // 
            btnInverter.Font = new Font("Segoe UI", 8F);
            btnInverter.Location = new Point(427, 206);
            btnInverter.Name = "btnInverter";
            btnInverter.Size = new Size(183, 53);
            btnInverter.TabIndex = 8;
            btnInverter.Text = "Inverter Primeiro";
            btnInverter.UseVisualStyleBackColor = true;
            btnInverter.Click += btnInverter_Click;
            // 
            // btnRemover
            // 
            btnRemover.Font = new Font("Segoe UI", 8F);
            btnRemover.Location = new Point(159, 205);
            btnRemover.Name = "btnRemover";
            btnRemover.Size = new Size(183, 53);
            btnRemover.TabIndex = 7;
            btnRemover.Text = "Remove Primeiro do Segundo";
            btnRemover.UseVisualStyleBackColor = true;
            btnRemover.Click += btnRemover_Click;
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Controls.Add(lblPalavra2);
            Controls.Add(lblPalavra1);
            Controls.Add(btnInverter);
            Controls.Add(btnRemover);
            Name = "frmExercicio3";
            Text = "frmExercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPalavra2;
        private TextBox txtPalavra1;
        private Label lblPalavra2;
        private Label lblPalavra1;
        private Button btnInverter;
        private Button btnRemover;
    }
}