namespace PFuncoes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //sem retorno e sem parametros
        void Soma()
        {
            double resultado = 5 + 6;
            MessageBox.Show(resultado.ToString());
        }

        //com retorno e sem parametros
        Double Soma1()
        {
            double resultado = 5 + 6;
            return resultado;
        }

        void Soma2(double x, double y)
        {
            x *= 10;
            double resultado = x + y;
            MessageBox.Show(resultado.ToString());
        }

        void Soma3(ref double x, double y)
        {
            x *= 10;
            y += 10;
            double resultado = x + y;
            MessageBox.Show(resultado.ToString());
        }

        Double Soma4(double x, double y, ref Double resultadoDobro)
        {
            resultadoDobro = (x + y) * 2;
            return x + y;
        }

        Double Soma5(Double X, Double Y, Double Z = 0)
        {
            if (Z > 0)
            {
                return (X + Y + Z) / 3;
            }
            else
            {
                return (X + Y) / 2;
            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            Soma();
        }

        private void btnSoma1_Click(object sender, EventArgs e)
        {
            double retorno = Soma1();
            MessageBox.Show(retorno.ToString());

        }

        private void btnSoma2_Click(object sender, EventArgs e)
        {
            double numero1 = 5;
            double numero2 = 6;
            Soma2(numero1, numero2);

            MessageBox.Show(numero1.ToString());
        }

        private void btnSoma3_Click(object sender, EventArgs e)
        {
            double numero1 = 5;
            double numero2 = 6;

            Soma3(ref numero1, numero2);

            MessageBox.Show(numero1.ToString());
            MessageBox.Show(numero2.ToString());
        }

        private void btnSoma4_Click(object sender, EventArgs e)
        {
            double r = 0;
            double numero1 = 5;
            double numero2 = 6;

            MessageBox.Show(Soma4(numero1, numero2, ref r).ToString());
            MessageBox.Show(r.ToString());
        }

        private void btnSoma5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sem 3� par�metro: " + Soma5(5, 6));
            MessageBox.Show("Com 3� parametro: " + Soma5(5, 6, 10));
        }

        private void btnFormatData_Click(object sender, EventArgs e)
        {
            DateTime data = DateTime.Now;
            MessageBox.Show("Data Curta = " + data.ToShortDateString());
            MessageBox.Show("Hora Extensa = " + data.ToLongTimeString());
            MessageBox.Show("Com Formatos = " + data.ToString("dd/MM/yyyy"));

            DateTime data2 = Convert.ToDateTime("12/05/2004");

            Double dias = data.Subtract(data2).TotalDays;
            MessageBox.Show("Diferen�a de dias = " + dias);

            DateTime novaData = data2.AddDays(10);
            MessageBox.Show("Nova Data = " + novaData);
        }
    }
}
