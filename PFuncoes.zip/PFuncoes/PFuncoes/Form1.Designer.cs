﻿namespace PFuncoes
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSoma = new Button();
            btnSoma1 = new Button();
            btnSoma2 = new Button();
            btnSoma3 = new Button();
            btnSoma4 = new Button();
            btnSoma5 = new Button();
            btnFormatData = new Button();
            SuspendLayout();
            // 
            // btnSoma
            // 
            btnSoma.Location = new Point(23, 205);
            btnSoma.Name = "btnSoma";
            btnSoma.Size = new Size(164, 108);
            btnSoma.TabIndex = 0;
            btnSoma.Text = "Soma";
            btnSoma.UseVisualStyleBackColor = true;
            btnSoma.Click += btnSoma_Click;
            // 
            // btnSoma1
            // 
            btnSoma1.Location = new Point(206, 205);
            btnSoma1.Name = "btnSoma1";
            btnSoma1.Size = new Size(164, 108);
            btnSoma1.TabIndex = 1;
            btnSoma1.Text = "Soma1";
            btnSoma1.UseVisualStyleBackColor = true;
            btnSoma1.Click += btnSoma1_Click;
            // 
            // btnSoma2
            // 
            btnSoma2.Location = new Point(390, 205);
            btnSoma2.Name = "btnSoma2";
            btnSoma2.Size = new Size(164, 108);
            btnSoma2.TabIndex = 2;
            btnSoma2.Text = "Soma2";
            btnSoma2.UseVisualStyleBackColor = true;
            btnSoma2.Click += btnSoma2_Click;
            // 
            // btnSoma3
            // 
            btnSoma3.Location = new Point(575, 205);
            btnSoma3.Name = "btnSoma3";
            btnSoma3.Size = new Size(164, 108);
            btnSoma3.TabIndex = 3;
            btnSoma3.Text = "Soma3";
            btnSoma3.UseVisualStyleBackColor = true;
            btnSoma3.Click += btnSoma3_Click;
            // 
            // btnSoma4
            // 
            btnSoma4.Location = new Point(760, 205);
            btnSoma4.Name = "btnSoma4";
            btnSoma4.Size = new Size(164, 108);
            btnSoma4.TabIndex = 4;
            btnSoma4.Text = "Soma4";
            btnSoma4.UseVisualStyleBackColor = true;
            btnSoma4.Click += btnSoma4_Click;
            // 
            // btnSoma5
            // 
            btnSoma5.Location = new Point(23, 334);
            btnSoma5.Name = "btnSoma5";
            btnSoma5.Size = new Size(164, 108);
            btnSoma5.TabIndex = 5;
            btnSoma5.Text = "Soma5";
            btnSoma5.UseVisualStyleBackColor = true;
            btnSoma5.Click += btnSoma5_Click;
            // 
            // btnFormatData
            // 
            btnFormatData.Location = new Point(206, 334);
            btnFormatData.Name = "btnFormatData";
            btnFormatData.Size = new Size(164, 108);
            btnFormatData.TabIndex = 6;
            btnFormatData.Text = "Formatação de Datas";
            btnFormatData.UseVisualStyleBackColor = true;
            btnFormatData.Click += btnFormatData_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(983, 524);
            Controls.Add(btnFormatData);
            Controls.Add(btnSoma5);
            Controls.Add(btnSoma4);
            Controls.Add(btnSoma3);
            Controls.Add(btnSoma2);
            Controls.Add(btnSoma1);
            Controls.Add(btnSoma);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnSoma;
        private Button btnSoma1;
        private Button btnSoma2;
        private Button btnSoma3;
        private Button btnSoma4;
        private Button btnSoma5;
        private Button btnFormatData;
    }
}
